// Buffer cache.
//
// The buffer cache is a linked list of buf structures holding
// cached copies of disk block contents.  Caching disk blocks
// in memory reduces the number of disk reads and also provides
// a synchronization point for disk blocks used by multiple processes.
//
// Interface:
// * To get a buffer for a particular disk block, call bread.
// * After changing buffer data, call bwrite to write it to disk.
// * When done with the buffer, call brelse.
// * Do not use the buffer after calling brelse.
// * Only one process at a time can use a buffer,
//     so do not keep them longer than necessary.


#include "types.h"
#include "param.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "riscv.h"
#include "defs.h"
#include "fs.h"
#include "buf.h"

#define TABLE_SIZE 13

struct {
  struct spinlock lock;
  struct spinlock locks[TABLE_SIZE];
  struct buf table[TABLE_SIZE][NBUF];
} bcache;

int
hash(int n)
{
  return n % TABLE_SIZE;
}

void
binit(void)
{
  struct spinlock *l;

  initlock(&bcache.lock, "bcache");

  for(l = bcache.locks; l < bcache.locks + TABLE_SIZE; ++l) {
    initlock(l, "bcache");
  }
}

// Look through buffer cache for block on device dev.
// If not found, allocate a buffer.
// In either case, return locked buffer.
static struct buf*
bget(uint dev, uint blockno)
{
  struct buf *b;

  // acquire(&bcache.lock);

  int bucketno = hash(blockno);
  acquire(&bcache.locks[bucketno]);
  struct buf* bucket = bcache.table[bucketno];

  for(int i = 0; i < NBUF; ++i) {

    b = &bucket[i];

    if(b->dev == dev && b->blockno == blockno) {
      b->refcnt++;
      release(&bcache.locks[hash(blockno)]);
      acquiresleep(&b->lock);
      return b;
     }
  }

  acquire(&bcache.lock);

  int t = ticks;
  int oldBuf = 0;
  uint freeBufs = 0;

  for(int i = 0; i < NBUF; ++i){
    b = &bucket[i];
    if (b->refcnt == 0) {
      ++freeBufs;
    }
    if (b->refcnt == 0 && b->lasttickused <= t) {
      oldBuf = i;
      t = b->lasttickused;
    }
  }

  if (freeBufs == 0) {
    panic("bget: no buffers");
  }

  b = &bucket[oldBuf];
  b->dev = dev;
  b->blockno = blockno;
  b->valid = 0;
  b->refcnt = 1;
  release(&bcache.locks[hash(blockno)]);
  release(&bcache.lock);
  acquiresleep(&b->lock);
  return b;
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    virtio_disk_rw(b->dev, b, 0);
    b->valid = 1;
  }
  return b;
}

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
  if(!holdingsleep(&b->lock))
    panic("bwrite");
  virtio_disk_rw(b->dev, b, 1);
}

// Release a locked buffer.
// Move to the head of the MRU list.
void
brelse(struct buf *b)
{
  if(!holdingsleep(&b->lock))
    panic("brelse");

  releasesleep(&b->lock);

  int bucketno = hash(b->blockno);
  acquire(&bcache.locks[bucketno]);
  b->refcnt--;
  if (b->refcnt == 0) {
    // no one is waiting for it.
    b->lasttickused = ticks;
  }

  release(&bcache.locks[bucketno]);
}

void
bpin(struct buf *b) {
  int bucketno = hash(b->blockno);
  acquire(&bcache.locks[bucketno]);
  b->refcnt++;
  release(&bcache.locks[bucketno]);
}

void
bunpin(struct buf *b) {
  int bucketno = hash(b->blockno);
  acquire(&bcache.locks[bucketno]);
  b->refcnt--;
  release(&bcache.locks[bucketno]);
}
