#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void sieve(int * left) {
  close(left[1]);
  int num;
  int p;
  int right[2];
  if (read(left[0], &p, 4) != 0) {
    printf("prime %d\n", p);
  } else {
    exit();
  }
  pipe(right);
  int pid = fork();
  if (pid == 0) {
    close(left[0]);
    close(right[1]);
    sieve(right);
  } else {
    close(right[0]);
    while(read(left[0], &num, 4) != 0) {
      if (num % p != 0) {
        write(right[1], &num, 4);
      }
    }
    close(left[0]);
    close(right[1]);
    exit();
  }
}

int
main(int argc, char *argv[])
{

  if(argc > 1){
    fprintf(2, "Usage: primes \n");
    exit();
  }

  int parent_fd[2];
  pipe(parent_fd);
  int pid = fork();
  if(pid == 0) {
    sieve(parent_fd);
  } else {
    for(int i = 2; i <= 35; i++) {
      write(parent_fd[1], &i, 4);
    }
    close(parent_fd[1]);
    close(parent_fd[0]);
    while(wait() != pid) {}
    exit();
  }
  exit();
}
