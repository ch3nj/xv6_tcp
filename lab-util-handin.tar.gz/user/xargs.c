#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/param.h"

int main(int argc, char **argv) {
  char buf[512];
  int index = 0;
  char c;
  char newline = '\n';

  while(read(0, &c, 1) > 0){
    if (c != newline) {
      buf[index++] = c;
    } else {
      int pid = fork();
      if (pid == 0) {
        char* args[MAXARG];
        for (int i = 0; i < argc - 1; ++i) {
          args[i] = argv[i + 1];
        }

        int arg_index = argc - 1;

        char* arg_word = "";
        for (int j = 0; j < strlen(buf); ++j){
          if(buf[j] == ' '){
            char * new_arg = (char*) malloc(sizeof(arg_word));
            strcpy(new_arg, arg_word);
            args[arg_index++] = new_arg;
            memset(arg_word,0,strlen(arg_word));
          }
          else{
            arg_word[strlen(arg_word)] = buf[j];
          }
        }
        args[arg_index] = arg_word;
        exec(argv[1], args);
        exit();
      }
      else {
        wait();
        memset(buf,0,strlen(buf));
        index = 0;
      }
    }
  }
  exit();
}
