#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{

  if(argc > 1){
    fprintf(2, "Usage: pingpong \n");
    exit();
  }

  int byte;
  int parent_fd[2];
  int child_fd[2];

  pipe(parent_fd);
  pipe(child_fd);

  int parent_pid = getpid();
  int child_pid = fork();

  if (getpid() == parent_pid) {
    close(parent_fd[0]);
    write(parent_fd[1], "x", 1);
    close(parent_fd[1]);
    close(child_fd[1]);
    read(child_fd[0], &byte, 1);
    printf("%d: received pong\n", parent_pid);
  } else {
    close(parent_fd[1]);
    read(parent_fd[1], &byte, 1);
    printf("%d: received ping\n", child_pid);
    close(parent_fd[0]);
    close(child_fd[0]);
    write(child_fd[1], "x", 1);
    close(child_fd[1]);
  }

  exit();
}
