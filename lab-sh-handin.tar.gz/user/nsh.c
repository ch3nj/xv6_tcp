#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/param.h"
#include "kernel/fcntl.h"

void runexeccmd(int argc, char **argv) {
  exec(argv[0], argv);
}

void runinputredircmd(int argc, char **argv) {
  // following code loosely based on sh.c
  for (int i = 0; i < argc; ++i) {
    if (strcmp(argv[i], "<") == 0) {
      char *file = argv[i+1];
      close(0);
      if(open(file, O_RDONLY) < 0) {
        fprintf(2, "open %s failed\n", file);
        exit(-1);
      }
      argv[i] = 0;
      runexeccmd(i, argv);
      exit(0);
    }
  }
  argv[argc] = 0;
  runexeccmd(argc, argv);
  exit(0);
}

void runoutputredircmd(int argc, char **argv) {
  // following code loosely based on sh.c
  for (int i = 0; i < argc; ++i) {
    if (strcmp(argv[i], ">") == 0) {
      char *file = argv[i+1];
      close(1);
      if(open(file, O_WRONLY|O_CREATE) < 0) {
        fprintf(2, "open %s failed\n", file);
        exit(-1);
      }
      argv[i] = 0;
      runinputredircmd(i, argv);
      exit(0);
    }
  }
  argv[argc] = 0;
  runinputredircmd(argc, argv);
  exit(0);
}

void runpipecmd(int argcleft, char **argvleft, int argcright, char **argvright) {
  int p[2];
  pipe(p);
  // following code based on sh.c - dup is very useful
  if (fork() == 0) {
    close(1);
    dup(p[1]);
    close(p[0]);
    close(p[1]);
    runoutputredircmd(argcleft, argvleft);
  }
  if (fork() == 0) {
    close(0);
    dup(p[0]);
    close(p[0]);
    close(p[1]);
    runoutputredircmd(argcright, argvright);
  }
  close(p[0]);
  close(p[1]);
  wait(0);
  wait(0);
  exit(0);
}

void runcmd(int argc, char **argv) {
  for (int i = 0; i < argc; ++i) {
    if (strcmp(argv[i], "|") == 0) {
      runpipecmd(i, argv, argc - i - 1, argv + i + 1);
      exit(0);
    }
  }
  runoutputredircmd(argc, argv);
  exit(0);
}

void parseruncmd(char *cmd) {
  char* args[MAXARG];
  int arg_index = 0;
  args[0] = &cmd[0];
  int len = strlen(cmd);
  for (int j = 0; j < len; ++j){
    if(cmd[j] == ' '){
      cmd[j] = '\0';
      args[++arg_index] = &cmd[j+1];
    }
  }
  runcmd(arg_index + 1, args);
  exit(0);
}

int main(int argc, char **argv) {
  char buf[512];
  int index = 0;
  char c;
  char newline = '\n';
  int pid;


  printf("@ ");

  while(read(0, &c, 1) > 0){
    if (c != newline) {
      buf[index++] = c;
    } else {
      pid = fork();
      if (pid == 0) {
        parseruncmd(buf);
      }
      else {
        wait(&pid);
        memset(buf,0,strlen(buf));
        index = 0;
        printf("@ ");
      }
    }
  }
  exit(0);
}
